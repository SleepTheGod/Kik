package kik.client;

import kik.client.common.Change;
import kik.client.common.SerializableObj;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

/**
 * Implementacja klasy obiektów przechowujących informacje o zmianie obecności
 * użytkownika w konferencji.
 * <p>
 * action przyjmuje dwie wartości:<br>
 * - "joined" - gdy użytkownik dołącza do konferencji - "exited" - gdy
 * użytkownik opuszcza konferencję.
 * <p>
 * Klasa jest wykorzystywana do informowania użytkowników o dołączeniu nowego
 * użytkownika do konferencji oraz informowania osoby zapraszającej, czy
 * przyjęte zostało zaproszenie do konferencji.
 * 
 * @author Bartłomiej Kucharczyk
 */
public class MemberChange extends Change implements SerializableObj {

	private String action; // joined lub exited
	private String member;

	public MemberChange(String _member, String _action, String _fromID) {
		super("");
		fromID = _fromID;
		member = _member;
		action = _action;
		type = "MemberChange";
	}

	/**
	 * Deserializuje obiekt.
	 * 
	 * @param objStr
	 *            Zserializowany obiekt w ciągu tekstowym.
	 * @see SerializableObj#deserialize(String)
	 */
	public Object deserialize(String objStr) {

		Document xml = XMLParser.parse(objStr);

		Element tmp = xml.getDocumentElement();
		if (tmp != null) {
			member = tmp.getAttribute("member");
			action = tmp.getAttribute("action");
			fromID = tmp.getAttribute("fromID");
		}
		return this;
	}

	public String getAction() {
		return action;
	}

	public String getMember() {
		return member;
	}

	/**
	 * Serializuje obiekt.
	 * 
	 * @return Zserializowany obiekt w ciągu tekstowym.
	 * @see SerializableObj#serialize()
	 */
	public String serialize() {
		Document xml = XMLParser.createDocument();

		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "MemberChange");
		tmp.setAttribute("fromID", fromID);
		tmp.setAttribute("member", member);
		tmp.setAttribute("action", action);

		xml.appendChild(tmp);

		return xml.toString();
	}

	/**
	 * @deprecated
	 */
	public String serialize(String fromID, String tool) {
		return null;
	}

	public void setAction(String _action) {
		action = _action;
	}

	public void setMember(String _member) {
		member = _member;
	}
}
