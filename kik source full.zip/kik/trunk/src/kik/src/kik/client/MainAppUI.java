package kik.client;

import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;

/**
 * Klasa MainAppUI odpowiada za utworzenie właściwego okna aplikacji.
 * Wyswietla panel zakładek konferencji oraz listę kontaktów użytkownika.
 * 
 * @author Paweł Kieliszczyk
 */
public class MainAppUI extends Composite {

	private DockPanel mainPanel = new DockPanel();

	/**
	 * Wyswietla panel zakładek konferencji oraz listę kontaktów użytkownika.
	 * 
	 * @param kik Klasa bazowa aplikacji.
	 * @param contactListUIinit Bazowy interefejs listy kontaktów użytkownika.
	 */
	public MainAppUI(Kik kik, ContactListUI contactListUIinit) {
		ConferencePanelUI conferencePanelUI = new ConferencePanelUI(kik);
		conferencePanelUI.addStyleName("conferencePanelUI");
		ContactListUI contactListUI = contactListUIinit;
		contactListUI.setConferencePanelUI(conferencePanelUI);
		contactListUI.addStyleName("contactListUI");

		mainPanel.add(conferencePanelUI, DockPanel.WEST);
		mainPanel.add(contactListUI, DockPanel.EAST);
		mainPanel.setCellHorizontalAlignment(contactListUI, HasHorizontalAlignment.ALIGN_RIGHT);

		initWidget(mainPanel);
	}
}
