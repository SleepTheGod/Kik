package kik.client.whiteboard;

import kik.client.common.Change;
import kik.client.whiteboard.Graphics.Tools;
import kik.client.common.SerializableObj;
import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

/**
 * Klasa definiująca obiekt zmiany na tablicy.
 *
 */
public class WhiteboardChange extends Change {
	/**
	 * Konstruktor
	 * 
	 * Pusty konstruktor, który służy do tworzenia obiektów, które ustawia się w poźniejszym czasie.
	 */
	
	/**
	 * Identyfikator narzędzia wywołującego zmianę
	 */
	protected Tools tool;
	
	public WhiteboardChange() {
		super("");
	}
	/**
	 * Konstruktor
	 * 
	 * @param confID	Identyfikator konferecencji
	 * @param changedObject	Obiekt graficzny, który został stworzony/zmieniony
	 * 
	 * @see Change
	 */
	public WhiteboardChange(String confID, Graphics changedObject, Tools tool) {
		super(confID);
		this.changedObject = changedObject;
		this.tool = tool;
	}
	
	/**
	 * Obiekt graficzny, który został stworzony/zmieniony
	 */
	private Graphics changedObject;

	/**
	 * Funkcja ustawiająca obiekt graficzny zmiany
	 * @param changedObject	Obiekt graficzny, który został stworzony/zmieniony
	 */
	public void setChangedObject(Graphics changedObject) {
		this.changedObject = changedObject;
	}
	
	/**
	 * @return Obiekt graficzny zmiany
	 */
	public Graphics getChangedObject() {
		return changedObject;
	}
	
	/**
	 * Prosta implementacja serializacji.
	 * @see SerializableObj
	 */
	public Object deserialize(String objStr) {
		Document xml = XMLParser.parse(objStr);
		
		Element tmp = xml.getDocumentElement();
		if(tmp != null){
			fromID = tmp.getAttribute("fromID");
			String graphicType = tmp.getAttribute("graphicType");
			String owner = tmp.getAttribute("owner");
			String ID = tmp.getAttribute("ID");
			Tools tool = Tools.valueOf((tmp.getAttribute("Tool")));
			this.tool = tool;
			if(tool == Tools.CLR) {
				changedObject = null;
			}
			else if(graphicType.compareTo("Rectangle") == 0)
				changedObject = (Graphics) new Rectangle(owner,ID).deserialize(objStr);
			else if(graphicType.compareTo("Line") == 0)
				changedObject = (Graphics) new Line(owner,ID).deserialize(objStr);
			else if(graphicType.compareTo("Text") == 0)
				changedObject = (Graphics) new Text(owner,ID).deserialize(objStr);
			else if(graphicType.compareTo("Image") == 0)
				changedObject = (Graphics) new Image(owner,ID).deserialize(objStr);
			else if(graphicType.compareTo("Circle") == 0)
				changedObject = (Graphics) new Circle(owner,ID).deserialize(objStr);
			else if(graphicType.compareTo("Brush") == 0)
				changedObject = (Graphics) new Brush(owner,ID).deserialize(objStr);
			else if(graphicType.compareTo("Locked") == 0)
				changedObject = (Graphics) new Locked(owner,ID).deserialize(objStr);
		}
		return this;
	}

	/**
	 * Funkcja domyślnie serializująca obiekt.
	 */
	public String serialize() {
		return this.changedObject.serialize(fromID, tool.toString());
	}
	/**
	 * Funkcja serializująca obiekt, która ustawia od kogo pochodzi obiekt oraz ustawia id narzędzia.
	 */
	public String serialize(String fromID, String tool) {
		return this.changedObject.serialize(fromID, tool);
	}
	
	/**
	 * Zwraca identyfikator zmiany.
	 * @return	Identyfikator zmiany.
	 */
	public Tools getTool() {
		return tool;
	}
	
	/**
	 * Ustawia identyfikator zmiany.
	 * @param _tool	Identyfikator zmiany.
	 */
	public void setTool(Tools _tool) {
		tool = _tool;
	}

}