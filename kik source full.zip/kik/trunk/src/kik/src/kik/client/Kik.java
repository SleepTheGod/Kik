package kik.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Klasa Kik jest klasą bazową systemu K.I.K. Odpowiada za tworzenie interfejsu
 * użytkownika oraz inicjację działania systemu.
 * 
 * @author Paweł Kieliszczyk
 */
public class Kik implements EntryPoint {

	private VerticalPanel mainPanel = new VerticalPanel();
	private LoginWindow loginWindow = new LoginWindow(this);
	private ContactList contactList;
	private ConferenceManager conferenceManager = new ConferenceManager();
	boolean appLoaded = false;
	boolean appShown = false;

	/**
	 * Zwraca referencję do managera konferencji.
	 * 
	 * @return Referencja do managera konferencji.
	 */
	public ConferenceManager getConferenceManager() {
		return conferenceManager;
	}

	/**
	 * Ukrywa wyświetloną w oknie przeglądarki aplikację.
	 */
	public void hideApp() {
		RootPanel.get("app").remove(mainPanel);
		appShown = false;

		GWT.log("Application hidden", null);
	}

	/**
	 * Określa czy aplikacja jest załadowana.
	 * 
	 * @return true, jesli załadowana; false, jeśli niezaładowana
	 */
	public boolean isAppLoaded() {
		return appLoaded;
	}

	/**
	 * Określa czy aplikacja jest wyświetlona w oknie przeglądarki.
	 * 
	 * @return true, jesli wyświetlona; false, jeśli niewyświetlona
	 */
	public boolean isAppShown() {
		return appShown;
	}

	/**
	 * Tworzy aplikację i ładuje interfejs użytkownika.
	 */
	public void loadApp() {
		ContactListUI contactListUI = new ContactListUI();
		contactList = new ContactList(loginWindow.getLogin(), contactListUI);
		conferenceManager.setContactList(contactList);
		conferenceManager.onContactChange(contactList);

		mainPanel.addStyleName("mainPanel");
		MenuUI menuUI = new MenuUI(this, loginWindow.getLogin());
		menuUI.addStyleName("menuUI");
		MainAppUI mainAppUI = new MainAppUI(this, contactListUI);
		mainAppUI.addStyleName("mainAppUI");

		mainPanel.add(menuUI);
		mainPanel.add(mainAppUI);
		mainPanel.setCellHeight(menuUI, "1px");

		appLoaded = true;

		GWT.log("Application loaded", null);
	}

	/**
	 * Metoda wejściowa. Jest wywoływana w momencie połączenia z serwerem.
	 * Inicjuje tworzenie okna logowania.
	 */
	public void onModuleLoad() {
		conferenceManager.onLoginChange(loginWindow);
		loginWindow.createLoginBox();
	}

	/**
	 * Informuje managera konferencji o utworzeniu nowego interfejsu panelu
	 * konferencji.
	 * 
	 * @param confPanelUI
	 *            Interfejs panelu konferencji
	 */
	public void sendConferencePanelUItoManager(ConferencePanelUI confPanelUI) {
		conferenceManager.setConferencePanelUI(confPanelUI);
	}

	/**
	 * Wyświetla aplikację w oknie przeglądarki. Ładuje aplikację do drzewa
	 * obiektów strony WWW. Powoduje pokazanie się aplikacji w przeglądarce.
	 */
	public void showApp() {
		RootPanel.get("app").add(mainPanel);
		appShown = true;

		GWT.log("Application shown", null);
	}

	/**
	 * Niszczy załadowaną aplikację.
	 */
	public void unloadApp() {
		mainPanel = new VerticalPanel();
		appLoaded = false;

		GWT.log("Application unloaded", null);
	}
}
