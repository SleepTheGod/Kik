package kik.client.whiteboard;

import java.util.Vector;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

import gwt.canvas.client.Canvas;

/**
 * Klasa Brush definiuje obiekty graficzne, które reprezentują ścieżke poprowadzoną pędzlem.
 *
 */
public class Brush extends Graphics {
	private Vector<Integer> x;
	private Vector<Integer> y;
	
	/**
	 * Podstawowy konstruktor definiujący tylko właściciela i identyfikator.
	 * @param owner	nazwa właściciela
	 * @param ID	identyfikator obiektu
	 */
	public Brush(String owner, String ID) {
		this.setID(ID);
		this.setOwner(owner);
	}
	
	/**
	 * Konstruktor definiujący krzywą narysowaną pędzlem
	 * @param x	Wektor wspórzędnych x narysowanej krzywej.
	 * @param y	Wektor wspórzędnych y narysowanej krzywej.
	 * @param board	Płótno, na którym jest rysowana krzywa.
	 * @param owner	Nazwa właściciela.
	 * @param ID	Identyfikator obiektu.
	 */
	public Brush(Vector<Integer> x, Vector<Integer> y, Canvas board, String owner, String ID) {
		this.x = x;
		this.y = y;
		this.board = board;
		this.setID(ID);
		this.setOwner(owner);
	}
	
	public boolean belongsTo(int x, int y) {
		for(int i = 1; i < this.x.size(); ++i) {
			Line tmp = new Line(this.x.get(i-1),this.y.get(i-1),this.x.get(i),this.y.get(i),board,"","");
			if(tmp.belongsTo(x, y))
				return true;
		}
		return false;
	}

	public void draw() {
		for(int i = 1; i < x.size(); ++i) {
			board.setStrokeStyle(color);
			board.beginPath();
			board.moveTo(x.get(i-1), y.get(i-1));
			board.lineTo(x.get(i), y.get(i));
			board.closePath();
			board.stroke();
		}
	}

	public void modifyCords(int rx, int ry) {
		for(int i = 0; i < this.x.size(); ++i) {
			int x = this.x.get(i);
			int y = this.y.get(i);
			this.x.set(i,x+rx);
			this.y.set(i,y+ry);
		}
		
	}

	public Object deserialize(String objStr) {
		Document xml = XMLParser.parse(objStr);
		
		Element tmp = xml.getDocumentElement();
		if(tmp != null){
			String xs = tmp.getAttribute("x");
			String ys = tmp.getAttribute("y");
			String xa[] = xs.split(";");
			String ya[] = ys.split(";");
			x = new Vector<Integer>();
			y = new Vector<Integer>();
			for(int i = 0; i < xa.length; ++i)
				x.add(Integer.parseInt(xa[i]));
			for(int i = 0; i < ya.length; ++i)
				y.add(Integer.parseInt(ya[i]));
			this.setOwner(tmp.getAttribute("owner"));
			this.setID(tmp.getAttribute("ID"));
			this.setColor(tmp.getAttribute("color"));
			this.setLocked(Boolean.parseBoolean(tmp.getAttribute("locked")));
		}
		return this;
	}
	public String serialize(String fromID, String tool) {
		Document xml = XMLParser.createDocument();
		
		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "WhiteboardChange");
		tmp.setAttribute("graphicType", "Brush");
		String xs = "";
		for(int i = 0; i < x.size(); ++i) {
			if(i > 0)
				xs += ";" + Integer.toString(x.get(i));
			else
				xs += Integer.toString(x.get(i));
		}
		
		tmp.setAttribute("x", xs);
		
		String ys = "";
		for(int i = 0; i < y.size(); ++i) {
			if(i > 0)
				ys += ";" + Integer.toString(y.get(i));
			else
				ys += Integer.toString(y.get(i));
		}
		tmp.setAttribute("y", ys);
		tmp.setAttribute("owner", getOwner());
		tmp.setAttribute("ID", getID());
		tmp.setAttribute("fromID", fromID);
		tmp.setAttribute("Tool", tool);
		tmp.setAttribute("locked", Boolean.toString(this.isLocked()));
		tmp.setAttribute("color", this.getColor());
		
		xml.appendChild(tmp);
		
		return xml.toString();
	}

	/**
	 * @deprecated
	 * Dla poprawnego dzialania serializacji obiektów należy podać infromacje
	 * na temat właściciela obiektu oraz typu zmiany (np dodanie) obiektu.
	 */
	public String serialize() {
		return null;
	}

}
