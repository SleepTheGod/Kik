package kik.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Klasa ButtonsPanel tworzy i wyświetla przyciski
 * zakładania konferencji i zapraszania znajomych do konferencji.
 * 
 * @author Paweł Kieliszczyk
 */
public class ButtonsPanel extends Composite {
	
	private VerticalPanel mainPanel = new VerticalPanel();
	private ContactListUI contactListUI;

	/**
	 * Tworzy przyciski zakładania konferencji i zapraszania
	 * znajomych do konferencji
	 * 
	 * @param contListUI Referencja do interfejsu listy kontaktów
	 */
	public ButtonsPanel(ContactListUI contListUI) {
		contactListUI = contListUI;
		
		Button createConferenceButton = new Button("Create Conference");
		Button inviteButton = new Button("Invite to Conference");
		createConferenceButton.addStyleName("createConferenceButton");
		inviteButton.addStyleName("createConferenceButton");
		
		// Nacisniecie przycisku powoduje utworzenie nowej konferencji
		createConferenceButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				contactListUI.getConferencePanelUI().addConferenceUI();
			}
		});
		
		// Nacisniecie przycisku powoduje zaproszenie uzytkownika do konferencji
		inviteButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				String user = contactListUI.getContactsTree().getSelectedItem().toString().split(">")[2].split("<")[0];
				GWT.log(user, null);
				Conference conf = contactListUI.getConferencePanelUI().getSelectedConference();
				conf.inviteMember(user);
			}
		});
		
		mainPanel.setSpacing(10);
		mainPanel.add(inviteButton);
		mainPanel.add(createConferenceButton);
		
		initWidget(mainPanel);
	}
	
}
