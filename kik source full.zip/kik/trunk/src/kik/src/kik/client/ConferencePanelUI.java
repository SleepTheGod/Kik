package kik.client;

import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.TabPanel;

/**
 * Klasa ConferencePanelUI odpowiada za zarządzanie
 * wyświetlaniem okien konferencji.
 * 
 * @author Paweł Kieliszczyk
 */
public class ConferencePanelUI extends Composite {

	private TabPanel mainPanel = new TabPanel();
	private int id = 0;
	Kik kik;

	/**
	 * Przekazuje swoją referencję do managera konferencji.
	 * Wyswietla panel do tworzenia zakładek konferencji.
	 * 
	 * @param kik Klasa bazowa aplikacji.
	 */
	public ConferencePanelUI(Kik kik) {
		this.kik = kik;
		this.kik.sendConferencePanelUItoManager(this);
		mainPanel.addStyleName("conferencePanelUI");
		initWidget(mainPanel);
	}

	/**
	 * Tworzy nową zakładkę z nową konferencją.
	 */
	public void addConferenceUI() {
		Conference conference = kik.getConferenceManager().newConference();
		conference.addStyleName("conference");
		mainPanel.add(conference, "Conference " + ++id);
		mainPanel.selectTab(mainPanel.getWidgetCount()-1);
	}

	/**
	 * Tworzy nową zakładkę z przekazaną konferencją.
	 * 
	 * @param conference Konferencja umieszczana w zakładce.
	 */
	public void addConferenceUI(Conference conference) {
		conference.addStyleName("conference");
		mainPanel.add(conference, "Conference " + ++id);
		mainPanel.selectTab(mainPanel.getWidgetCount()-1);
	}

	/**
	 * Zwraca aktualnie otwartą zakładkę konferencji.
	 * 
	 * @return Numer otwartej zakładki.
	 */
	public int getSelectedTab() {
		return mainPanel.getTabBar().getSelectedTab();
	}

	/**
	 * Zwraca konferencję z aktualnie otwartej zakładki.
	 * 
	 * @return Referencja do konferencji z aktualnie otwartej zakładki.
	 */
	public Conference getSelectedConference() {
		int index = getSelectedTab();
		return (Conference)mainPanel.getWidget(index);
	}

	/**
	 * Usuwa konferencję z panelu
	 * 
	 * @param conf Konferencja do usunięcia.
	 */
	public void removeConference(Conference conf) {
		mainPanel.remove(conf);
	}

}
