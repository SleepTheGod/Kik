package kik.client.chat;

import kik.client.common.Change;
import kik.client.common.SerializableObj;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

/**
 * Implementacja zmian w chat'cie.
 * 
 * @author Bartłomiej Kucharczyk
 * 
 */
public class ChatChange extends Change {

	/**
	 * Wiadomość tekstowa do przesłania
	 */
	private String textChange;
	/**
	 * Konstruktor
	 * 
	 * Pusty konstruktor, który służy do tworzenia obiektów, które ustawia się w poźniejszym czasie.
	 */
	public ChatChange() {
		super("");
	}

	/**
	 * Konstruktor obiektu ChatChange.
	 * 
	 * @param confID Nazwa konferencji w której nastąpiła zmiana.
	 * @param msg Wiadomość tekstowa jaka została przesłana.
	 */
	public ChatChange(String confID, String msg) {
		super(confID);
		textChange = msg;
	}

	/**
	 * Prosta implementacja deserializacji.
	 * 
	 * @see Change
	 */
	public Object deserialize(String objStr) {
		Document xml = XMLParser.parse(objStr);

		Element tmp = xml.getDocumentElement();
		if (tmp != null) {
			textChange = tmp.getAttribute("textChange");
			fromID = tmp.getAttribute("fromID");
		}
		return this;
	}

	/**
	 * Pobranie tekstu jaki został odebrany.
	 * 
	 * @return Wiadomość tekstowa odebrana od jakiegoś użytkownika.
	 */
	public String getTextChange() {
		return textChange;
	}

	/**
	 * Prosta implementacja serializacji.
	 * 
	 * @see SerializableObj
	 */
	public String serialize() {
		Document xml = XMLParser.createDocument();

		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "ChatChange");
		tmp.setAttribute("textChange", textChange);
		tmp.setAttribute("fromID", fromID);

		xml.appendChild(tmp);

		return xml.toString();
	}

	/**
	 * @depreciated
	 * Używane przy zmianach tablicy.
	 */
	public String serialize(String fromID, String tool) {
		return null;
	}

	/**
	 * Ustawienie wiadomości, jaka ma zostać przesłana.
	 * 
	 * @param _textChange Przesyłana wiadomość.
	 */
	public void setTextChange(String _textChange) {
		textChange = _textChange;
	}
}