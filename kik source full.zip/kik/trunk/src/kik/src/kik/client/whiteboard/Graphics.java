package kik.client.whiteboard;

import kik.client.common.SerializableObj;
import gwt.canvas.client.Canvas;

/**
 * Klasa abstrakcyjna obiektów graficznych.
 * 
 */
public abstract class Graphics implements SerializableObj {
	public enum Tools { RECTANGLE, CIRCLE, LINE, MOVE, BRUSH, TEXT, UP, DOWN, DEL, IMG, CLR, LOCK, NEW};
	private String name = "";
	private String owner = "";
	private String ID = "";
	private Whiteboard myWhiteboard;
	protected boolean locked = false;
	protected String color = "#000000";

	/**
	 * Płótno, na którym rysowany jest obiekt graficzny.
	 */
	protected Canvas board;

	/**
	 * Funkcja sprawdzająca należność punktu do obiektu graficznego.
	 * 
	 * @param x
	 *            współrzędna x punktu
	 * @param y
	 *            współrzędna y punktu
	 * @return zmienna logiczna, prawda gdy punkt należy do obiektu, fałsz w
	 *         przeciwnym przypadku
	 */
	public abstract boolean belongsTo(int x, int y);

	/**
	 * Funkcja rysująca obiekt graficzny na płótnie.
	 */
	public abstract void draw();

	/**
	 * Pobieranie obiektu płótna, na którym rysuje się obiekt graficzny.
	 * 
	 * @return Płótno.
	 */
	public Canvas getCanva() {
		return this.board;
	}

	/**
	 * Pobieranie koloru.
	 * 
	 * @return Hexadecymalna reprezentacja koloru (np #1C34F6001).
	 */
	public String getColor() {
		return color;
	}

	/**
	 * Pobieranie identyfikatora obiektu.
	 * 
	 * @return Identyfikator obiektu.
	 */
	public String getID() {
		return ID;
	}

	/**
	 * Pobieranie obiektu tablicy, do której należy obiekt.
	 * 
	 * @return Tablica.
	 */
	public Whiteboard getMyWhiteboard() {
		return myWhiteboard;
	}

	/**
	 * Pobieranie nazwy obiektu.
	 * 
	 * @return Nazwa obiektu.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Pobieranie właściciela obiektu.
	 * 
	 * @return Nazwa właściciela obiektu.
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * Sprawdzanie czy obiekt jest zablokowany.
	 * 
	 * @return Prawda jeżli jest zablokowany, fa?sz w przeciwnym przypadku.
	 */
	public boolean isLocked() {
		return locked;
	}

	/**
	 * Funkcja do zmiany współrzędnych, na współrzędne względne.
	 * 
	 * @param rx
	 *            współrzędna przesunięcia x
	 * @param ry
	 *            współrzędna przesunięcia y
	 */
	public abstract void modifyCords(int rx, int ry);

	/**
	 * Ustawianie obiektu płótna, na którym rysuje się obiekt graficzny.
	 * 
	 * @param board
	 *            Płótno.
	 */
	public void setCanva(Canvas board) {
		this.board = board;
	}

	/**
	 * Ustawianie koloru.
	 * 
	 * @param color
	 *            Hexadecymalna reprezentacja koloru (np #1C34F6001).
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * Ustawianie identyfikator obiektu.
	 * 
	 * @param ID
	 *            Identyfikator obiektu.
	 */
	public void setID(String ID) {
		this.ID = ID;
	}

	/**
	 * Blokowanie obiektu, np przy przesuwaniu
	 * 
	 * @param locked
	 *            Zmienna logiczna, prawda jeżli ma zostać zablokowany, fałsz w
	 *            przeciwnym przypadku.
	 */
	public void setLocked(boolean locked) {
		;
		this.locked = locked;
	}

	/**
	 * Ustawianie obiektu tablicy, do której należy obiekt.
	 * 
	 * @param myWhiteboard
	 *            Tablica.
	 */
	public void setMyWhiteboard(Whiteboard myWhiteboard) {
		this.myWhiteboard = myWhiteboard;
	}

	/**
	 * Ustawianie nazwy obiektu.
	 * 
	 * @param name
	 *            Nowa nazwa obiektu.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Ustawianie właściciela obiektu.
	 * 
	 * @param owner
	 *            Nazwa właściciela.
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
}