package kik.client.common;

/**
 * Interfejs obiektu, który potrafi sam siebie serializować. Autor musi zapewnić
 * poprawność działania serializacji i deserializacji.
 * <p>
 * Implementacja może wykorzystywać dowolny typ danych wyjściowych. Zalecany
 * jest XML.
 * 
 * @author Bartłomiej Kucharczyk
 * 
 */
public interface SerializableObj {
	/**
	 * Metoda odtwarzająca zawartość z ciągu tekstowego. Musi być to zrobione w
	 * ten sposób, ponieważ GWT nie udostępnia wbudowanej serializacji obiektów.
	 * 
	 * @param objStr
	 *            Zserializowany obiekt.
	 */
	public Object deserialize(String objStr);

	/**
	 * Metoda zwracająca serializację siebie do ciągu tekstowego. Musi być to
	 * zrobione w ten sposób, ponieważ GWT nie udostępnia wbudowanej
	 * serializacji obiektów.
	 * 
	 * @return Zserializowany obiekt.
	 */
	public String serialize();

	/**
	 * 
	 * Metoda zwracająca serializację siebie do ciągu tekstowego. 
	 *
	 * @param fromID ID konferencji z której pochodzi obiekt.
	 * @param tool Numer narzędzia. 
	 * @return Zserializowany obiekt.
	 * @see #serialize()
	 */
	public String serialize(String fromID, String tool);

}
