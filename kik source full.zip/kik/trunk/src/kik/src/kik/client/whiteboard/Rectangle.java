package kik.client.whiteboard;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

import gwt.canvas.client.Canvas;

/**
 * Klasa Rectangle definiuje obiekty graficzne, które reprezentują prostokąt.
 *
 */
public class Rectangle extends Graphics {
	private int x,y,w,h;
	
	/**
	 * Podstawowy konstruktor definiujący tylko właściciela i identyfikator.
	 * @param owner	nazwa właściciela
	 * @param ID	identyfikator obiektu
	 */
	public Rectangle(String owner, String ID) {
		this.setID(ID);
		this.setOwner(owner);
	}
	
	/**
	 * Konstruktor definiujący prostokąt.
	 * @param x
	 * @param y
	 * @param w	szerokość prostokąta
	 * @param h	wysokość prostokąta
	 * @param board	płótno, na którym jest rysowany prostokąt
	 * @param owner	nazwa właściciela
	 * @param ID	identyfikator obiektu
	 */
	public Rectangle(int x, int y, int w, int h, Canvas board, String owner, String ID) {
		if(w < 0) {
			x = x + w;
			w = -w;
		}
		this.x = x;
		this.w = w;
		if(h < 0) {
			y = y + h;
			h = -h;
		}
		this.y = y;
		this.h = h;
		this.board = board;
		this.setID(ID);
		this.setOwner(owner);
	}

	public void draw() {
		board.setStrokeStyle("#FFFFFF");
		board.strokeRect(x, y, w, h);
		board.setStrokeStyle(color);
		board.setFillStyle("#FFFFFF");
		board.fillRect(x, y, w, h);
		board.strokeRect(x, y, w, h);
	}
	
	public boolean belongsTo(int x, int y) {
		if(x>=this.x && y>=this.y && x<=this.x+this.w && y<=this.y+this.h) {
			return true;
		}
		return false;
	}
	
	public void modifyCords(int rx, int ry) {
		this.x+=rx;
		this.y+=ry;
	}

	public Object deserialize(String objStr) {
		Document xml = XMLParser.parse(objStr);
		
		Element tmp = xml.getDocumentElement();
		if(tmp != null){
			x = Integer.parseInt(tmp.getAttribute("x"));
			y = Integer.parseInt(tmp.getAttribute("y"));
			w = Integer.parseInt(tmp.getAttribute("width"));
			h = Integer.parseInt(tmp.getAttribute("height"));
			this.setOwner(tmp.getAttribute("owner"));
			this.setID(tmp.getAttribute("ID"));
			this.setColor(tmp.getAttribute("color"));
			this.setLocked(Boolean.parseBoolean(tmp.getAttribute("locked")));
		}
		return this;
	}

	public String serialize(String fromID, String tool) {
		Document xml = XMLParser.createDocument();
		
		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "WhiteboardChange");
		tmp.setAttribute("graphicType", "Rectangle");
		tmp.setAttribute("width", Integer.toString(w));
		tmp.setAttribute("height", Integer.toString(h));
		tmp.setAttribute("x", Integer.toString(x));
		tmp.setAttribute("y", Integer.toString(y));
		tmp.setAttribute("owner", getOwner());
		tmp.setAttribute("ID", getID());
		tmp.setAttribute("fromID", fromID);
		tmp.setAttribute("Tool", tool);
		tmp.setAttribute("locked", Boolean.toString(this.isLocked()));
		tmp.setAttribute("color", this.getColor());
		
		xml.appendChild(tmp);
		
		return xml.toString();
	}

	/**
	 * @deprecated
	 * Dla poprawnego dzialania serializacji obiektów należy podać infromacje
	 * na temat właściciela obiektu oraz typu zmiany (np dodanie) obiektu.
	 */
	public String serialize() {
		return null;
	}
}