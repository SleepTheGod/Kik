package kik.client;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;

/**
 * Klasa MenuUI odpowiada za utworzenie paska menu
 * zawierającego tekst powitalny oraz przycisk wylogowania.
 * 
 * @author Paweł Kieliszczyk
 */
public class MenuUI extends Composite {

	Kik kik;
	private DockPanel mainPanel = new DockPanel();

	/**
	 * Tworzony jest tekst powitalny użytkownika
	 * oraz przycisk Disconnect służący do rozłączenie się z serwerem XMPP.
	 * 
	 * @param kikk Klasa bazowa aplikacji.
	 * @param login Login użytkownika do serwera XMPP.
	 */
	public MenuUI(Kik kikk, String login) {
		kik = kikk;
		Button disconnectButton = new Button("Disconnect");
		disconnectButton.addStyleName("disconnectButton");
		
		disconnectButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				kik.getConferenceManager().disconnect();
			}
		});
		
		HTML helloText = new HTML("Hello, <b>" + login.split("@")[0] + "</b>");

		mainPanel.add(helloText, DockPanel.WEST);
		mainPanel.add(disconnectButton, DockPanel.EAST);
		mainPanel.setCellHorizontalAlignment(disconnectButton, HasHorizontalAlignment.ALIGN_RIGHT);

		initWidget(mainPanel);
	}

}
