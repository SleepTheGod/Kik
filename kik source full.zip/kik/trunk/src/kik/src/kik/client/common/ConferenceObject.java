package kik.client.common;

import kik.client.Conference;
import com.google.gwt.user.client.ui.Composite;

/**
 * Klasa definiująca podstawowe elementy obiektów konferencji.
 *
 */
public class ConferenceObject extends Composite {
	/**
	 * Identyfikator obiektu.
	 */
	protected String id;
	
	/**
	 * Właściciel obiektu.
	 */
	protected String owner;
	
	/**
	 * Referencja do obiektu konferencji.
	 * @see Conference
	 */
	protected Conference conf;

	/**
	 * Ustawia identyfikator obiektu.
	 * @param id	Identyfikator.
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Zwraca identyfikator obiektu.
	 * @return	Identyfikator.
	 */
	public String getId() {
		return id;
	}
}