package kik.client;

import java.util.ArrayList;

import com.calclab.emite.core.client.xmpp.stanzas.Presence;
import com.calclab.suco.client.events.Listener;

/**
 * Klasa ContactList służy do zarządzania listą kontaktów
 * użytkownika. 
 * 
 * @author Paweł Kieliszczyk
 */
public class ContactList implements Listener<Presence> {
	private ContactListUI contactListUI = new ContactListUI();
	private String login;
	private ArrayList<String> online = new ArrayList<String>();
	private ArrayList<String> offline = new ArrayList<String>();

	/**
	 * Konstruktor klasy. Ustawia login i interfejs listy kontaktów.
	 * @param login Login użytkownika do serwera XMPP
	 * @param contactListUI Klasa odpowiedzialna za wyświetlanie listy kontaktów w przeglądarce
	 */
	public ContactList(String login, ContactListUI contactListUI) {
		this.login = login;
		this.contactListUI = contactListUI;
	}

	/**
	 * Metoda wywoływana w momencie zmiany kontaktu.
	 * Sprawdza aktualny status kontaktu i uaktualnia
	 * jego stan na liście kontaktów.
	 */
	public void onEvent(Presence presence) {
		String from = presence.getFromAsString().split("/")[0];
		if(from.equals(login))
			return;
		String show = presence.getShow().toString();
		
		if(show.equals("notSpecified")) {
			//user is online
			if(!online.contains(from)) {
				offline.remove(from);
				online.add(from);
				contactListUI.updateContactsTree(online, offline);
			}
		}
		else {
			// user is not online
			if(online.contains(from)) {
				online.remove(from);
				offline.add(from);
				contactListUI.updateContactsTree(online, offline);
			}
		}
		if(presence.getType() != null) {
			String type = presence.getType().toString();
			if(!type.equals("unavailable")) {
				//user is online
				if(!online.contains(from)) {
					offline.remove(from);
					online.add(from);
					contactListUI.updateContactsTree(online, offline);
				}
			}
			else {
				// user is not online
				if(online.contains(from)) {
					online.remove(from);
					offline.add(from);
					contactListUI.updateContactsTree(online, offline);
				}
			}
		}
	}

	/**
	 * Ustawia listę kontaktów użytkownika.
	 * Metoda jest wywoływana w momencie zalogowania, ale przed ustawieniem
	 * statusu Ready.
	 * 
	 * @param rost Tablica zawierająca kontakty użytkownika
	 */
	public void setRoster(ArrayList<String> rost) {
		offline = rost;
		contactListUI.updateContactsTree(online, offline);
	}

}
