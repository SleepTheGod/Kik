package kik.client.whiteboard;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

public class Locked extends Graphics {
	Locked(String owner, String ID) {
		this.setName("Locked");
		this.setID(ID);
		this.setOwner(owner);
	}
	@Override
	public boolean belongsTo(int x, int y) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyCords(int rx, int ry) {
		// TODO Auto-generated method stub
		
	}

	public Object deserialize(String objStr) {
		Document xml = XMLParser.parse(objStr);
		
		Element tmp = xml.getDocumentElement();
		if(tmp != null){
			this.setOwner(tmp.getAttribute("owner"));
			this.setID(tmp.getAttribute("ID"));
		}
		return this;
	}

	public String serialize() {
		// TODO Auto-generated method stub
		return null;
	}

	public String serialize(String fromID, String tool) {
		Document xml = XMLParser.createDocument();
		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "WhiteboardChange");
		tmp.setAttribute("graphicType", "Locked");
		tmp.setAttribute("owner", getOwner());
		tmp.setAttribute("ID", getID());
		tmp.setAttribute("fromID", fromID);
		tmp.setAttribute("Tool", tool);
		
		xml.appendChild(tmp);
		
		return xml.toString();
	}

}
