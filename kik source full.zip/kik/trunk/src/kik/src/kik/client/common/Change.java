package kik.client.common;

/**
 * Abstrakcyjna klasa zmian.
 * 
 * @author Bartłomiej Kucharczyk
 *
 */
public abstract class Change implements SerializableObj {
	
	/**
	 * Identyfikator konferencji, w której została wykonana zmiana.
	 */
	protected String fromID = "";
	
	/**
	 * Nazwa użytkownika, od którego przyszła zmiana.
	 */
	protected String fromUser = "";
	
	/**
	 * Typ zmiany, potrzebny do prowizorycznej deserializacji. Może być jeden z:
	 * "ChatChange", "ConferenceChange", "ConferenceChange", "ContactChange", "WhiteboardChange".
	 */
	protected String type = "";

	/**
	 * Konstruktor.
	 * 
	 * @param _fromID	Identyfikator konferencji.
	 * @see #fromID
	 */
	protected Change(String _fromID){
		fromID = _fromID;
	}
	
	/**
	 * Ustawia typ zmiany.
	 * 
	 * @param newType Nowy typ zmiany Change.
	 */
	public void setType(String newType){
		type = newType;
	}
	
	/**
	 * Zwraca typ zmiany.
	 * 
	 * @return Typ zmiany.
	 * @see #type
	 */
	public String getType(){
		return type;
	}
	
	/**
	 * Zwraca nazwę użytkownika, od którego przyszła zmiana.
	 * @return	Nazwa użytkownika.
	 */
	public String getFromUser(){
		return fromUser;
	}
	
	/**
	 * Ustawia użytkownika, od którego wychodzi zmiana.
	 * @param _fromUser	Nazwa użytkownika.
	 */
	public void setFromUser(String _fromUser){
		fromUser = _fromUser;
	}

	/**
	 * Zwraca identyfikator użytkownika, od którego przyszła zmiana.
	 * @return	Identyfikator użytkownika
	 */
	public String getFromID(){
		return fromID;
	}
	
	/**
	 * Ustawia identyfikator użytkownika, od którego wychodzi zmiana.
	 * @param _fromID	Identyfikator użytkownika.
	 */
	public void setFromID(String _fromID){
		fromID = _fromID;
	}
}