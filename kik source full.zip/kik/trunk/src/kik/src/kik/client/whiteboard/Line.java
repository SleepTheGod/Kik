package kik.client.whiteboard;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

import gwt.canvas.client.Canvas;

/**
 * Klasa Line definiuje obiekty graficzne, które reprezentują linie proste.
 *
 */
public class Line extends Graphics {
	private int x,y,x2,y2;
	
	/**
	 * Podstawowy konstruktor definiujący tylko właściciela i identyfikator.
	 * @param owner	Nazwa właściciela
	 * @param ID	identyfikator obiektu
	 */
	public Line(String owner, String ID) {
		this.setID(ID);
		this.setOwner(owner);
	}
	/**
	 * Konstruktor definiujący linię prostą.
	 * @param x	Współrzędna x początku linii.
	 * @param y	Współrzędna y początku linii.
	 * @param x2	Współrzędna x końca linii.
	 * @param y2	Współrzędna y końca linii.
	 * @param board	Płótno, na którym rysowana jest linia.
	 * @param owner	Nazwa właściciela.
	 * @param ID	Identyfikator obiektu.
	 */
	public Line(int x, int y, int x2, int y2, Canvas board,String owner, String ID) {
		this.x = x;
		this.y = y;
		this.x2 = x2;
		this.y2 = y2;
		this.board = board;
		this.setID(ID);
		this.setOwner(owner);
	}

	public void draw() {
		board.setStrokeStyle(color);
		board.beginPath();
		board.moveTo(x, y);
		board.lineTo(x2, y2);
		board.closePath();
		board.stroke();
	}
	
	public boolean belongsTo(int px, int py) {
		double det = Math.abs((x*y2+y*px+x2*py)-(y2*px+x*py+y*x2));
		if(det < 100 && Math.min(x, x2)-2 <= px && Math.min(y, y2)-2 <= py
				&& Math.max(x, x2)+2 >= px && Math.max(y, y2)+2 >= py)
			return true;
		return false;
	}
	
	public void modifyCords(int rx, int ry) {
		x += rx;
		x2 += rx;
		y += ry;
		y2 += ry;
	}

	public Object deserialize(String objStr) {
		Document xml = XMLParser.parse(objStr);
		
		Element tmp = xml.getDocumentElement();
		if(tmp != null){
			x = Integer.parseInt(tmp.getAttribute("x"));
			y = Integer.parseInt(tmp.getAttribute("y"));
			x2 = Integer.parseInt(tmp.getAttribute("x2"));
			y2 = Integer.parseInt(tmp.getAttribute("y2"));
			this.setOwner(tmp.getAttribute("owner"));
			this.setID(tmp.getAttribute("ID"));
			this.setColor(tmp.getAttribute("color"));
			this.setLocked(Boolean.parseBoolean(tmp.getAttribute("locked")));
		}
		return this;
	}

	public String serialize(String fromID, String tool) {
		Document xml = XMLParser.createDocument();
		
		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "WhiteboardChange");
		tmp.setAttribute("graphicType", "Line");
		tmp.setAttribute("x", Integer.toString(x));
		tmp.setAttribute("y", Integer.toString(y));
		tmp.setAttribute("x2", Integer.toString(x2));
		tmp.setAttribute("y2", Integer.toString(y2));
		tmp.setAttribute("owner", getOwner());
		tmp.setAttribute("ID", getID());
		tmp.setAttribute("fromID", fromID);
		tmp.setAttribute("Tool", tool);
		tmp.setAttribute("locked", Boolean.toString(this.isLocked()));
		tmp.setAttribute("color", this.getColor());
		
		xml.appendChild(tmp);
		
		return xml.toString();
	}
	
	/**
	 * @deprecated
	 * Dla poprawnego dzialania serializacji obiektów należy podać infromacje
	 * na temat właściciela obiektu oraz typu zmiany (np dodanie) obiektu.
	 */
	public String serialize() {
		return null;
	}
}