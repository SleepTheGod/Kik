package kik.client.whiteboard;


import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

import gwt.canvas.client.Canvas;

/**
 * Klasa Circle definiuje obiekty graficzne, które reprezentują koło.
 *
 */
public class Circle extends Graphics {
	private int x,y;
	private double radius;
	
	/**
	 * Podstawowy konstruktor definiujący tylko właściciela i identyfikator.
	 * @param owner	Nazwa właściciela
	 * @param ID	identyfikator obiektu
	 */
	public Circle(String owner, String ID) {
		this.setID(ID);
		this.setOwner(owner);
	}
	
	/**
	 * Konstruktor definiujący koło.
	 * @param x	Współrzędna x środka koła.
	 * @param y	Współrzędna y środka koła.
	 * @param radius	Promień koła.
	 * @param board	Płótno, na którym jest rysowane koło.
	 * @param owner	Nazwa właściciela.
	 * @param ID	Identyfikator obiektu.
	 */
	public Circle(int x, int y, double radius, Canvas board, String owner, String ID) {
		this.x = x;
		this.y = y;
		this.radius = radius;
		this.board = board;
		this.setID(ID);
		this.setOwner(owner);
	}
	
	public void draw() {
		board.setStrokeStyle(color);
		board.beginPath();
		board.arc(x, y, radius, 0, 2*Math.PI, false);
		board.closePath();
		board.setFillStyle("#FFFFFF");
		board.fill();
		board.stroke();
	}
	
	public boolean belongsTo(int x, int y) {
		if((double)((x-this.x)*(x-this.x)+(y-this.y)*(y-this.y))<=(radius*radius)) {
			return true;
		}
		return false;
	}
	
	public void modifyCords(int rx, int ry) {
		this.x+=rx;
		this.y+=ry;
	}
	public Object deserialize(String objStr) {
		Document xml = XMLParser.parse(objStr);
		
		Element tmp = xml.getDocumentElement();
		if(tmp != null){
			x = Integer.parseInt(tmp.getAttribute("x"));
			y = Integer.parseInt(tmp.getAttribute("y"));
			radius = Double.parseDouble((tmp.getAttribute("radius")));
			this.setOwner(tmp.getAttribute("owner"));
			this.setID(tmp.getAttribute("ID"));
			this.setColor(tmp.getAttribute("color"));
			this.setLocked(Boolean.parseBoolean(tmp.getAttribute("locked")));
		}
		return this;
	}
	public String serialize(String fromID, String tool) {
		Document xml = XMLParser.createDocument();
		
		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "WhiteboardChange");
		tmp.setAttribute("graphicType", "Circle");
		tmp.setAttribute("x", Integer.toString(x));
		tmp.setAttribute("y", Integer.toString(y));
		tmp.setAttribute("radius", Double.toString(radius));
		tmp.setAttribute("owner", getOwner());
		tmp.setAttribute("ID", getID());
		tmp.setAttribute("fromID", fromID);
		tmp.setAttribute("Tool", tool);
		tmp.setAttribute("locked", Boolean.toString(this.isLocked()));
		tmp.setAttribute("color", this.getColor());
		
		xml.appendChild(tmp);
		
		return xml.toString();
	}

	/**
	 * @deprecated
	 * Dla poprawnego dzialania serializacji obiektów należy podać infromacje
	 * na temat właściciela obiektu oraz typu zmiany (np dodanie) obiektu.
	 */
	public String serialize() {
		return null;
	}	
}