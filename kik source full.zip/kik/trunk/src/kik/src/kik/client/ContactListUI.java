package kik.client;

import java.util.ArrayList;

import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DockPanel;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.Tree;
import com.google.gwt.user.client.ui.TreeItem;

/**
 * Klasa ConferencePanelUI odpowiada za wyświetlenie listy kontaktów
 * oraz odpowiada za interakcję użytkownika z systemem w zakresie
 * tworzenia i zapraszania znajomych do konferencji.
 * 
 * @author Paweł Kieliszczyk
 */
public class ContactListUI extends Composite {

	private DockPanel mainPanel = new DockPanel();
	private ConferencePanelUI conferencePanelUI;
	private Tree contactsTree = new Tree();
	private TreeItem onlineFriends;
	private TreeItem offlineFriends;

	/**
	 * Tworzy drzewka zawierające kontakty użytkownika i wyświetla je na ekranie.
	 * Tworzy przycisku do tworzenia i zapraszania zanajomych do konferencji.
	 */
	public ContactListUI() {
		ButtonsPanel buttonsPanel = new ButtonsPanel(this);
		buttonsPanel.addStyleName("buttonsPanel");
		mainPanel.add(buttonsPanel, DockPanel.SOUTH);
		mainPanel.setCellVerticalAlignment(buttonsPanel, HasVerticalAlignment.ALIGN_BOTTOM);

		initWidget(mainPanel);
	}

	/**
	 * Aktualizuje drzewko zawierające listę kontaktów użytkownika.
	 *
	 * @param usersList Lista znajomych użytkownika.
	 */
	public void updateContactsTree(ArrayList<String> online, ArrayList<String> offline) {
		mainPanel.remove(contactsTree);
		
		contactsTree = new Tree();
		onlineFriends = new TreeItem();
		offlineFriends = new TreeItem();
		
		onlineFriends.setText("online");
		offlineFriends.setText("offline");
		
		for(int i = 0; i < online.size(); ++i) {
			onlineFriends.addItem(online.get(i));
		}
		for(int i = 0; i < offline.size(); ++i) {
			offlineFriends.addItem(offline.get(i));
		}
		
		onlineFriends.setState(true);
		offlineFriends.setState(true);
		
		contactsTree.addItem(onlineFriends);
		contactsTree.addItem(offlineFriends);
		
		mainPanel.add(contactsTree, DockPanel.NORTH);
	}

	/**
	 * Ustawia referencję do panelu zakładek konferencji.
	 * 
	 * @param confPanelUI Referencja do panelu zakładek konferencji.
	 */
	public void setConferencePanelUI(ConferencePanelUI confPanelUI) {
		conferencePanelUI = confPanelUI;
	}

	/**
	 * Zwraca referencję do panelu zakładek konferencji.
	 *
	 * @return Referencja do panelu zakładek konferencji.
	 */
	public ConferencePanelUI getConferencePanelUI() {
		return conferencePanelUI;
	}

	/**
	 * Zwraca referencję do drzewka znajomych użytkownika.
	 * 
	 * @return Referencja do drzewka znajomych użytkownika.
	 */
	public Tree getContactsTree() {
		return contactsTree;
	}

}
