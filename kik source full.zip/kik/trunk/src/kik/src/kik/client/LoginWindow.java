package kik.client;

import com.calclab.suco.client.events.*;
import com.calclab.emite.core.client.xmpp.session.*;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

/**
 * Klasa LoginWindow tworzy okno umożliwiające wprowadzenie
 * loginu i hasła do serwera XMPP.
 * Inicjuje połączenie użytkownika z serwerem.
 * Inicjuje załadowanie aplikacji w oknie przeglądarki.
 * 
 * @author Paweł Kieliszczyk
 */
public class LoginWindow implements Listener<Session.State> {

	Kik kik;
	private String login;
	private String password;

	final DialogBox loginBox = new DialogBox();
	final TextBox loginField = new TextBox();
	final PasswordTextBox passwordField = new PasswordTextBox();

	/**
	 * Konstruktor klasy.
	 * 
	 * @param kik Klasa bazowa aplikacji
	 */
	LoginWindow(Kik kik) {
		this.kik = kik;
	}

	/**
	 * Tworzy okno dialogowe służące do wprowadzania
	 * loginu i hasła do serwera XMPP.
	 */
	public void createLoginBox() {
		final Button connectButton = new Button("Connect");
		connectButton.addStyleName("connectButton");
		
		loginField.setText("test1@localhost");
		passwordField.setText("test1");

		// Tworzymy okno dialogowe do logowania
		loginBox.setText("Login Window");
		loginBox.setAnimationEnabled(true);
		VerticalPanel loginPanel = new VerticalPanel();
		loginPanel.add(new HTML("<b>Login:</b>"));
		loginPanel.add(loginField);
		loginPanel.add(new HTML("<br><b>Password:</b>"));
		loginPanel.add(passwordField);
		loginPanel.add(new HTML("<br>"));
		loginPanel.setHorizontalAlignment(VerticalPanel.ALIGN_RIGHT);
		loginPanel.add(connectButton);
		loginBox.setWidget(loginPanel);
		loginBox.center();
		loginField.setFocus(true);
		
		// Nacisniecie przycisku powoduje zamkniecie okna
		connectButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				connect();
			}
		});
		
		// Wcisniecie Enter powoduje zamkniecie okna
		loginField.addKeyPressHandler(new KeyPressHandler() {
			public void onKeyPress(KeyPressEvent event) {
				if(event.getCharCode() == '\r' ||
						event.getCharCode() == '\n') {
					connect();
				}
			}
		});
		
		// Wcisniecie Enter powoduje zamkniecie okna
		passwordField.addKeyPressHandler(new KeyPressHandler() {
			public void onKeyPress(KeyPressEvent event) {
				if(event.getCharCode() == '\r' ||
						event.getCharCode() == '\n') {
					connect();
				}
			}
		});
	}

	/**
	 * Inicjuje połądzenie użytkownika z serwerem XMPP
	 */
	private void connect() {
		login = loginField.getText();
		password = passwordField.getText();
		
		kik.getConferenceManager().connect(login, password);
	}

	/**
	 * Zwraca login użytkownika
	 * 
	 * @return Login użytkownika.
	 */
	public String getLogin() {
		return login;
	}

	/**
	 * Zwraca hasło użytkownika.
	 * 
	 * @return Hasło użytkownika.
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * Pokazuje na ekranie okno dialogowe służące
	 * do wprowadzania loginu i hasła do serwera XMPP.
	 */
	public void showLoginBox() {
		loginBox.show();
	}

	/**
	 * Ukrywa okno dialogowe służące do wprowadzania
	 * loginu i hasła do serwera XMPP.
	 */
	public void hideLoginBox() {
		loginBox.hide();
	}

	/**
	 * Metoda wywoływana w momencie zmiany stanu użytkownika.
	 * W zależności od stanu wykonywane są różne operacje, takie jak
	 * ukrywanie i pokazywanie okna dialogowego
	 */
	public void onEvent(Session.State state) {
		if(state == Session.State.loggedIn){
			hideLoginBox();
			if(!kik.isAppLoaded())
				kik.loadApp();
			if(!kik.isAppShown())
				kik.showApp();
		}
		else if(state == Session.State.disconnected){
			if(kik.isAppShown())
				kik.hideApp();
			if(kik.isAppLoaded())
				kik.unloadApp();
			showLoginBox();
		}
		else if(state == Session.State.notAuthorized){
			GWT.log("Bledy uzytkownik lub haslo!", null);
		}
		else if(state == Session.State.error){
			GWT.log("Nieokreslony blad!", null);
		}
	}
}
