package kik.client;

import java.util.ArrayList;

import kik.client.common.Change;
import kik.client.common.SerializableObj;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

/**
 * Implementacja klasy przechowującej informacje o nowych konferencjach.
 * <p>
 * Służy do zapraszania użytkowników do konferencji. Wewnątrz zakapsułkowana
 * jest lista użytkowników aktualnie w konferencji. W przypadku akceptacji lub
 * odrzucenia konferencji należy wysłać informację o tym do użytkownika
 * zapraszającego, w obiekcie klasy MemberChange.
 * 
 * @author Bartłomiej Kucharczyk
 */
public class NewConference extends Change implements SerializableObj {

	private ArrayList<String> members;

	public NewConference(ArrayList<String> memb, String _fromUser,
			String _fromID) {
		super("");
		fromUser = _fromUser;
		fromID = _fromID;
		members = memb;
	}

	/**
	 * Deserializuje obiekt.
	 * 
	 * @param objStr
	 *            Zserializowany obiekt w ciągu tekstowym.
	 * @see SerializableObj#deserialize(String)
	 */
	public Object deserialize(String objStr) {
		members = new ArrayList<String>();

		Document xml = XMLParser.parse(objStr);

		Element tmp = xml.getDocumentElement();
		if (tmp != null) {
			for (String m : tmp.getAttribute("members").split(":")) {
				if (m.length() > 0)
					members.add(m);
			}

			fromUser = tmp.getAttribute("fromUser");
			fromID = tmp.getAttribute("fromID");
		}
		return this;
	}

	/**
	 * Zwraca tablicę członków konferencji.
	 * 
	 * @return Lista członków konferencji
	 */
	public ArrayList<String> getMembers() {
		return members;
	}

	/**
	 * Serializuje obiekt.
	 * 
	 * @return Zserializowany obiekt w ciągu tekstowym.
	 * @see SerializableObj#serialize()
	 */
	public String serialize() {
		Document xml = XMLParser.createDocument();

		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "NewConference");
		tmp.setAttribute("fromUser", fromUser);
		tmp.setAttribute("fromID", fromID);

		String out = "";
		for (String m : members) {
			out += m + ":";
		}
		if (out.length() > 0)
			out = out.substring(0, out.length() - 1);
		else
			out = "";

		tmp.setAttribute("members", out);
		xml.appendChild(tmp);

		return xml.toString();
	}

	/**
	 * @deprecated
	 */
	public String serialize(String fromID, String tool) {
		return null;
	}

	public void setMembers(ArrayList<String> memb) {
		members = memb;
	}

}
