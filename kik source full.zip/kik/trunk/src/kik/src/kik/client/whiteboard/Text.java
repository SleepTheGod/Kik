package kik.client.whiteboard;

import com.google.gwt.xml.client.Document;
import com.google.gwt.xml.client.Element;
import com.google.gwt.xml.client.XMLParser;

import gwt.canvas.client.Canvas;

public class Text extends Graphics {
	private int x,y,w,h;
	String text = "";
	
	/**
	 * Podstawowy konstruktor definiujący tylko właściciela i identyfikator.
	 * @param owner	nazwa właściciela
	 * @param ID	identyfikator obiektu
	 */
	public Text(String owner, String ID) {
		this.setID(ID);
		this.setOwner(owner);
	}
	
	/**
	 * Konstruktor definiujący pole tekstowe.
	 * @param x	Współrzędne x początku pola tekstowego.
	 * @param y	Współrzędne y początku pola tekstowego.
	 * @param text	Wartość wyświetlanego tekstu.
	 * @param board	Płótno, na którym jest rysowany tekst.
	 * @param owner	Nazwa właściciela.
	 * @param ID	Identyfikator obiektu.
	 */
	public Text(int x, int y, String text, Canvas board,String owner, String ID) {
		this.board = board;
		this.text = text;
		this.w = this.text.length()*5;
		this.h = 10;
		this.x = x;
		this.y = y;
		this.setID(ID);
		this.setOwner(owner);
	}
	
	public boolean belongsTo(int x, int y) {
		if(x >= this.x && x <= this.x+w && y <= this.y && y >= this.y -h) {
			return true;
		}
		return false;
	}
	@Override
	public void draw() {
		board.setFillStyle("#000000");
		board.fillText(this.text, this.x, this.y);
	}

	public void modifyCords(int rx, int ry) {
		this.x = this.x+rx;
		this.y = this.y+ry;
	}

	public Object deserialize(String objStr) {
		Document xml = XMLParser.parse(objStr);
		
		Element tmp = xml.getDocumentElement();
		if(tmp != null){
			this.x = Integer.parseInt(tmp.getAttribute("x"));
			this.y = Integer.parseInt(tmp.getAttribute("y"));
			this.text = tmp.getAttribute("text");
			this.setOwner(tmp.getAttribute("owner"));
			this.setID(tmp.getAttribute("ID"));
			this.h = 10;
			this.w = text.length()*5;
			this.setColor(tmp.getAttribute("color"));
			this.setLocked(Boolean.parseBoolean(tmp.getAttribute("locked")));
		}
		return this;
	}

	public String serialize(String fromID, String tool) {
		Document xml = XMLParser.createDocument();
		
		Element tmp = xml.createElement("data");
		tmp.setAttribute("type", "WhiteboardChange");
		tmp.setAttribute("graphicType", "Text");
		tmp.setAttribute("x", Integer.toString(x));
		tmp.setAttribute("y", Integer.toString(y));
		tmp.setAttribute("text", text);
		tmp.setAttribute("owner", getOwner());
		tmp.setAttribute("ID", getID());
		tmp.setAttribute("fromID", fromID);
		tmp.setAttribute("Tool", tool);
		tmp.setAttribute("locked", Boolean.toString(this.isLocked()));
		tmp.setAttribute("color", this.getColor());
		
		xml.appendChild(tmp);
		
		return xml.toString();
	}

	/**
	 * @deprecated
	 * Dla poprawnego dzialania serializacji obiektów należy podać infromacje
	 * na temat właściciela obiektu oraz typu zmiany (np dodanie) obiektu.
	 */
	public String serialize() {
		return null;
	}

	
}
